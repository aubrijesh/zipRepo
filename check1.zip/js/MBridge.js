/**
 * MBridge - Micro App Bridge for Capacitor Native Features
 * 
 * Common Usage Examples:
 * 
 * // Camera Operations
 * const photo = await MBridge.camera.takePhoto({ quality: 80, resultType: 'uri' });
 * const galleryPhoto = await MBridge.camera.pickFromGallery();
 * 
 * // File Operations
 * await MBridge.filesystem.writeFile({ path: 'data.txt', data: 'Hello World', directory: 'Documents' });
 * const content = await MBridge.filesystem.readFile({ path: 'data.txt', directory: 'Documents' });
 * 
 * // Device Info
 * const deviceInfo = await MBridge.device.getInfo();
 * const battery = await MBridge.device.getBatteryInfo();
 * const isOnline = await MBridge.utils.isOnline();
 * 
 * // User Interactions
 * await MBridge.toast.showLong('Operation completed!');
 * await MBridge.utils.showSuccess('Data saved successfully');
 * await MBridge.utils.showError('Something went wrong');
 * 
 * // Data Storage
 * await MBridge.storage.set('user_preferences', JSON.stringify(prefs));
 * const prefs = JSON.parse((await MBridge.storage.get('user_preferences')).value || '{}');
 * 
 * // Or use utility methods:
 * await MBridge.utils.saveAppData('settings', { theme: 'dark', lang: 'en' });
 * const settings = await MBridge.utils.loadAppData('settings');
 * 
 * // Sharing
 * await MBridge.utils.shareContent('Check this out!', 'Amazing micro-app feature');
 * 
 * // Clipboard
 * await MBridge.utils.copyToClipboard('Text to copy');
 * const clipboardText = await MBridge.clipboard.read();
 * 
 * // Advanced: Capture and save image
 * const photo = await MBridge.utils.captureAndSaveImage('photo_' + Date.now() + '.jpg');
 */

let reqCounter = 0;

function sendBridgeRequest(type, payload = {}) {
  return new Promise((resolve, reject) => {
    const requestId = `req_${Date.now()}_${++reqCounter}`;

    function handler(event) {
      const { requestId: resId, result, error } = event.data || {};
      if (resId !== requestId) return;
      window.removeEventListener('message', handler);

      if (error) reject(error);
      else resolve(result);
    }

    window.addEventListener('message', handler);
    window.parent.postMessage({ type, payload, requestId }, '*');
  });
}

// Expose a simple API for microapps
window.MBridge = {
  // Camera Operations
  camera: {
    takePhoto: (options = {}) => sendBridgeRequest('camera.takePhoto', options),
    pickFromGallery: (options = {}) => sendBridgeRequest('camera.pickFromGallery', options),
  },

  // Filesystem Operations
  filesystem: {
    readFile: (options) => sendBridgeRequest('filesystem.readFile', options),
    writeFile: (options) => sendBridgeRequest('filesystem.writeFile', options),
    deleteFile: (options) => sendBridgeRequest('filesystem.deleteFile', options),
    mkdir: (options) => sendBridgeRequest('filesystem.mkdir', options),
    rmdir: (options) => sendBridgeRequest('filesystem.rmdir', options),
    readdir: (options) => sendBridgeRequest('filesystem.readdir', options),
    stat: (options) => sendBridgeRequest('filesystem.stat', options),
  },

  // Device Information
  device: {
    getInfo: () => sendBridgeRequest('device.getInfo'),
    getBatteryInfo: () => sendBridgeRequest('device.getBatteryInfo'),
    getLanguageCode: () => sendBridgeRequest('device.getLanguageCode'),
  },

  // Network Status
  network: {
    getStatus: () => sendBridgeRequest('network.getStatus'),
  },

  // UI Interactions
  toast: {
    show: (text, options = {}) => sendBridgeRequest('toast.show', { text, ...options }),
    showShort: (text) => sendBridgeRequest('toast.show', { text, duration: 'short' }),
    showLong: (text) => sendBridgeRequest('toast.show', { text, duration: 'long' }),
  },

  // Share
  share: {
    share: (options) => sendBridgeRequest('share.share', options),
    shareText: (text, title = '') => sendBridgeRequest('share.share', { text, title }),
    shareUrl: (url, title = '') => sendBridgeRequest('share.share', { url, title }),
  },

  // Clipboard
  clipboard: {
    write: (text) => sendBridgeRequest('clipboard.write', { string: text }),
    read: () => sendBridgeRequest('clipboard.read'),
  },

  // Storage (Key-Value Preferences)
  storage: {
    get: (key) => sendBridgeRequest('storage.get', { key }),
    set: (key, value) => sendBridgeRequest('storage.set', { key, value }),
    remove: (key) => sendBridgeRequest('storage.remove', { key }),
    clear: () => sendBridgeRequest('storage.clear'),
    keys: () => sendBridgeRequest('storage.keys'),
  },

  // Status Bar
  statusBar: {
    setStyle: (style) => sendBridgeRequest('statusbar.setStyle', { style }),
    setBackgroundColor: (color) => sendBridgeRequest('statusbar.setBackgroundColor', { color }),
    show: () => sendBridgeRequest('statusbar.show'),
    hide: () => sendBridgeRequest('statusbar.hide'),
  },

  // Splash Screen
  splashScreen: {
    show: () => sendBridgeRequest('splashscreen.show'),
    hide: () => sendBridgeRequest('splashscreen.hide'),
  },

  // Platform Utilities
  platform: {
    getPlatform: () => sendBridgeRequest('capacitor.getPlatform'),
    isNativePlatform: () => sendBridgeRequest('capacitor.isNativePlatform'),
    convertFileSrc: (fileSrc) => sendBridgeRequest('capacitor.convertFileSrc', { fileSrc }),
  },

  // Utility methods for common tasks
  utils: {
    // Save and load app data
    async saveAppData(key, data) {
      return window.MBridge.storage.set(key, JSON.stringify(data));
    },
    
    async loadAppData(key) {
      const result = await window.MBridge.storage.get(key);
      return result.value ? JSON.parse(result.value) : null;
    },

    // Check if device is online
    async isOnline() {
      const status = await window.MBridge.network.getStatus();
      return status.connected;
    },

    // Get device platform info
    async getDevicePlatform() {
      const info = await window.MBridge.device.getInfo();
      return {
        platform: info.platform,
        model: info.model,
        operatingSystem: info.operatingSystem,
        osVersion: info.osVersion,
      };
    },

    // Show success/error messages
    async showSuccess(message) {
      return window.MBridge.toast.showLong(`✅ ${message}`);
    },

    async showError(message) {
      return window.MBridge.toast.showLong(`❌ ${message}`);
    },

    // Copy text to clipboard with feedback
    async copyToClipboard(text) {
      try {
        await window.MBridge.clipboard.write(text);
        await this.showSuccess('Copied to clipboard!');
        return true;
      } catch (error) {
        await this.showError('Failed to copy to clipboard');
        return false;
      }
    },

    // Save image from camera
    async captureAndSaveImage(filename) {
      try {
        const photo = await window.MBridge.camera.takePhoto({ 
          quality: 80, 
          resultType: 'base64' 
        });
        
        await window.MBridge.filesystem.writeFile({
          path: filename,
          data: photo.base64String,
          directory: 'Documents'
        });
        
        await this.showSuccess('Image saved successfully!');
        return photo;
      } catch (error) {
        await this.showError('Failed to capture and save image');
        throw error;
      }
    },

    // Share app content
    async shareContent(title, text, url = null) {
      try {
        await window.MBridge.share.share({ title, text, url });
        return true;
      } catch (error) {
        await this.showError('Failed to share content');
        return false;
      }
    },
  },
};

// Convenience aliases for common operations
window.MBridge.showToast = window.MBridge.toast.show;
window.MBridge.saveData = window.MBridge.utils.saveAppData;
window.MBridge.loadData = window.MBridge.utils.loadAppData;
