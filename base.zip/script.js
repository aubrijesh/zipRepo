// Developer by: Enrique Mosqueira @eknowmad
// Inspired by: https://dribbble.com/shots/2363674-Levitating-Product-Card/attachments/453393