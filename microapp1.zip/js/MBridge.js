let reqCounter = 0;

function sendBridgeRequest(type, payload = {}) {
  return new Promise((resolve, reject) => {
    const requestId = `req_${Date.now()}_${++reqCounter}`;

    function handler(event) {
      const { requestId: resId, result, error } = event.data || {};
      if (resId !== requestId) return;
      window.removeEventListener('message', handler);

      if (error) reject(error);
      else resolve(result);
    }

    window.addEventListener('message', handler);
    window.parent.postMessage({ type, payload, requestId }, '*');
  });
}

// Expose a simple API for microapps
window.MBridge = {
  camera: {
    takePhoto: () => sendBridgeRequest('camera.takePhoto'),
  },
  filesystem: {
    readFile: (options) => sendBridgeRequest('filesystem.readFile', options),
    writeFile: (options) => sendBridgeRequest('filesystem.writeFile', options),
  },
};
